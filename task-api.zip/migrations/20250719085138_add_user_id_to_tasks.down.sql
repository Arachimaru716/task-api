ALTER TABLE tasks
  DROP COLUMN user_id;